#ifndef __PROYECTO_FUSE__
#define __PROYECTO_FUSE__

#define block_size 1024

#include <fuse.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdint.h>

#define block_size 1024

typedef struct superblock {
	char datablocks[block_size*100];		// Número total de data blocks.
	char data_bitmap[105];	    			// Array de los números de data block disponibles.
	char inode_bitmap[105];   				// Array de los números de inodo que hay disponibles.
} superblock;

typedef struct inode {
	int datablocks[16];    			// Número de data block al que el inicio apunta.
	int number;
	int blocks;                    // Número de bloques a los que apunta el inodo particular.
	//int link;                    // Número de links.
	int size;                      // Tamaño del file ó directory.
} inode;

typedef struct filetype {
	int valid;
	char test[10];
	char path[100];
	char name[100];           		// Nombre.
	inode *inum;             		// Número de inodo.
	struct filetype ** children;
	int num_children;
	int num_links;
	struct filetype * parent;
	char type[20];                  // Extensión del file.
	mode_t permissions;		        // Permisos.
	uid_t user_id;		            // ID del usuario.
	gid_t group_id;		            // ID del group.
	time_t a_time;                  // Tiempo de aceso.
	time_t m_time;                  // Tiempo de modificación.
	time_t c_time;                  // Tiempo de cambio de Status.
	time_t b_time;                  // Tiempo de Creación.
	off_t size;                     // Tamaño del nodo.

	int datablocks[16];
	int number;
	int blocks;

} filetype;

superblock spblock;

void initialize_superblock(){
	memset(spblock.data_bitmap, '0', 100 * sizeof(char));
	memset(spblock.inode_bitmap, '0', 100 * sizeof(char));
}

filetype file_array[50];  // Array donde se almacena cada fichero.

void tree_to_array(filetype * queue, int * front, int * rear, int * index){
	if(rear < front)
		return;
	if(*index > 30)
		return;

	filetype curr_node = queue[*front];
	// *front += 1;
	*front++;
	file_array[*index] = curr_node;
	// *index += 1;
	*index++;

	if(*index < 6){
		if(curr_node.valid){
			int n = 0;
			int i;
			for(i = 0; i < curr_node.num_children; i++){
				if(*rear < *front)
					*rear = *front;
				queue[*rear] = *(curr_node.children[i]);
				// *rear += 1;
				*rear++;
			}
			while(i < 5){
				filetype waste_node;
				waste_node.valid = 0;
				queue[*rear] = waste_node;
				// *rear += 1;
				*rear++;
				i++;
			}
		} else {
			int i = 0;
			while(i < 5){
				filetype waste_node;
				waste_node.valid = 0;
				queue[*rear] = waste_node;
				// *rear += 1;
				*rear++;
				i++;
			}
		}
	}
	tree_to_array(queue, front, rear, index);
}

#endif
