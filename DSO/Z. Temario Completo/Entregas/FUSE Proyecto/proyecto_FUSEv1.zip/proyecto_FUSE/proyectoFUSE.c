#define FUSE_USE_VERSION 30

// Importo mi libería con la structura de mi FileSystem.
#include "proyectoFUSE_lib.h"

#include <fuse.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

// Declaración de la Raíz.
filetype * root;

void initialize_root_directory(){
	spblock.inode_bitmap[1] = 1;
	root = (filetype *) malloc (sizeof(filetype));

	strcpy(root->path, "/");
	strcpy(root->name, "/");

	root -> children = NULL;
	root -> num_children = 0;
	root -> parent = NULL;
	root -> num_links = 2;
	root -> valid = 1;

	strcpy(root->test, "test");
	strcpy(root -> type, "directory");
	// root -> type = malloc(10);	

	// Inicializo todo a NULL.
	root->c_time = time(NULL);
	root->a_time = time(NULL);
	root->m_time = time(NULL);
	root->b_time = time(NULL);

	// Doy los permisos de directorio.
	root -> permissions = S_IFDIR | 0777;

	root -> size = 0;
	root->group_id = getgid();
	root->user_id = getuid();

	root -> number = 2;
	root -> blocks = 0;
	// root -> size = 0;
}

/* Esta función devuelve toda la información necesaria del PATH que se le mande por parámetro,
   devuelve una estrucutra del tipo filetype.
   Por ejemplo, estoy en /BIG.
*/
filetype * filetype_from_path(char * path){
	// Array donde voy a almacenar el nombre de mi carpeta actual.
	char curr_folder[100];
	// Le sumo dos para  aumentar + 1 el puntero luego y el \0.
	char * path_name = malloc(strlen(path) + 2);
	// Copiamos path a path_name.
	strcpy(path_name, path);

	// Inicializamos un nodo como raíz.
	filetype * curr_node = root;

	fflush(stdin);
	// Estamos en nuestra RAÍZ.
	if(strcmp(path_name, "/") == 0){
		return curr_node;
	}

	// PATH incorrecto.
	if(path_name[0] != '/'){
		printf("INCORRECT PATH\n");
		// Si no tiene "/" no es un PATH válido, se sale.
		exit(1);
	} else {  // Si es el PATH es correcto, movemos el puntero uno a la derecha.
		// Pasaría a estar en BIG en vez de en /BIG.
		path_name++;
	}

	// Si solo tengo "/" es que soy la raíz.
	if(path_name[strlen(path_name) - 1] == '/'){
		// El \0 indica  el final.
		path_name[strlen(path_name) - 1] = '\0';
	}

	char * index;
	int flag = 0;

	// Mientras que siga habiendo PATH... /BIG/Rafita/Doraemon.
	while(strlen(path_name) != 0){
		// Muevo index hasta el siguiente "/".
		index = strchr(path_name, '/');
		
		// Significa que sigue habiendo más PATH que investigar, tengo que llegas hasta /Doraemon.
		if(index != NULL){
			strncpy(curr_folder, path_name, index - path_name);
			curr_folder[index-path_name] = '\0';
			
			flag = 0;
			for(int i = 0; i < curr_node -> num_children; i++){
				if(strcmp((curr_node -> children)[i] -> name, curr_folder) == 0){
					curr_node = (curr_node -> children)[i];
					flag = 1;
					break;
				}
			}
			if(flag == 0){
				return NULL;
			}
		// No tengo más PATH que visitar, he llegado hasta el final.
		} else {
			strcpy(curr_folder, path_name);
			flag = 0;
			for(int i = 0; i < curr_node -> num_children; i++){
				if(strcmp((curr_node -> children)[i] -> name, curr_folder) == 0){
					curr_node = (curr_node -> children)[i];
					return curr_node;
				}
			}
			return NULL;
		}
		// Muevo mi index hacia la derecha.
		path_name = index + 1;
	}
}

int find_free_inode(){
	for(int i = 2; i < 100; i++){
		if(spblock.inode_bitmap[i] == '0'){
			spblock.inode_bitmap[i] = '1';
		}
		return i;
	}
}

// Este método es neceario solo para crear FILES.
int find_free_db(){
	for(int i = 1; i < 100; i++){
		if(spblock.inode_bitmap[i] == '0'){
			spblock.inode_bitmap[i] = '1';
		}
		return i;
	}
}

void add_child(filetype * parent, filetype * child){
	(parent -> num_children)++;
	parent -> children = realloc(parent -> children, (parent -> num_children) * sizeof(filetype *));
	(parent -> children)[parent -> num_children - 1] = child;
}

static int mygetattr(const char *path, struct stat *statit){
	char *pathname;
	pathname = (char *) malloc(strlen(path) + 2);

	strcpy(pathname, path);

	printf("GETATTR %s\n", pathname);

	filetype * file_node = filetype_from_path(pathname);
	if(file_node == NULL){
		return -ENOENT;
	}

	// El dueño del arhivo ó del directorio es el usuario que monta el filesystem.
	statit->st_uid = file_node -> user_id;
	// El grupo del archivo ó del directorio es el mismo que el grupo del usuario que montó el sistema de archivos.
	statit->st_gid = file_node -> group_id;
	// El último acceso al arhivo ó directorio está aquí.
	statit->st_atime = file_node -> a_time;
	// La última modificación del arhivo ó directorio está aquí.
	statit->st_mtime = file_node -> m_time;
	statit->st_ctime = file_node -> c_time;
	statit->st_mode = file_node -> permissions;
	statit->st_nlink = file_node -> num_links + file_node -> num_children;
	statit->st_size = file_node -> size;
	statit->st_blocks = file_node -> blocks;

	return 0;
}

static int myreaddir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi ){
	printf("READDIR\n");

	// Creo primero "." y "..".
	filler(buffer, ".", NULL, 0 );
	filler(buffer, "..", NULL, 0 );

	char * pathname = malloc(strlen(path) + 2);
	strcpy(pathname, path);

	filetype * dir_node = filetype_from_path(pathname);

	if(dir_node == NULL){
		return -ENOENT;
	} else {
		dir_node->a_time = time(NULL);
		for(int i = 0; i < dir_node->num_children; i++){
			printf(":%s:\n", dir_node->children[i]->name);
			filler( buffer, dir_node->children[i]->name, NULL, 0);
		}
	}

	return 0;
}

static int myopen(const char *path, struct fuse_file_info *fi){
	printf("OPEN\n");

	// Pido memoria.
	char * pathname = malloc(sizeof(path) + 1);
	// Copio el "path" que me llega por parámetro, el que quiero abrir, en "pathname".
	strcpy(pathname, path);
	// Recupero todos los datos de ese "pathname".
	filetype * file = filetype_from_path(pathname);

	return 0;
}

static int myread(const char *path, char *buf, size_t size, off_t offset,struct fuse_file_info *fi){
	printf("READ\n");

	char * pathname = malloc(sizeof(path) + 1);
	strcpy(pathname, path);

	filetype * file = filetype_from_path(pathname);
	if(file == NULL){
		return -ENOENT;
	} else {
		char * str = malloc(sizeof(char) * 1024 * (file -> blocks));

		printf(":%ld:\n", file->size);
		strcpy(str, "");
		int i;
		for(i = 0; i < (file -> blocks) - 1; i++){
			strncat(str, &spblock.datablocks[block_size*(file -> datablocks[i])], 1024);
			printf("--> %s", str);
		}
		strncat(str, &spblock.datablocks[block_size*(file -> datablocks[i])], (file -> size) % 1024);
		printf("--> %s", str);
		//strncpy(str, &spblock.datablocks[block_size*(file -> datablocks[0])], file->size);
		strcpy(buf, str);
	}
	return file->size;
}

static int myrename(const char* from, const char* to) {
	printf("RENAME: %s\n", from);
	printf("RENAME: %s\n", to);

	char * pathname = malloc(strlen(from) + 2);
	strcpy(pathname, from);

	char * rindex1 = strrchr(pathname, '/');

	filetype * file = filetype_from_path(pathname);

	*rindex1 = '\0';

	char * pathname2 = malloc(strlen(to) + 2);
	strcpy(pathname2, to);

	char * rindex2 = strrchr(pathname2, '/');

	if(file == NULL){
		return -ENOENT;
	}

	strcpy(file -> name, rindex2 + 1);
	strcpy(file -> path, to);	
	//file -> name = realloc(file -> name, strlen(rindex2 + 1) + 2);	
	//file -> path = realloc(file -> path, strlen(to) + 2);

	printf(":%s:\n", file->name);
	printf(":%s:\n", file->path);

	return 0;
}

static int mymkdir(const char *path, mode_t mode){
	printf("MKDIR\n");

	int index = find_free_inode();

	filetype * new_folder = malloc(sizeof(filetype));

	char * pathname = malloc(strlen(path) + 2);
	strcpy(pathname, path);
	char * rindex = strrchr(pathname, '/');

	strcpy(new_folder -> name, rindex + 1);
	strcpy(new_folder -> path, pathname);
	//new_folder -> name = malloc(strlen(pathname) + 2);	
	//new_folder -> path = malloc(strlen(pathname) + 2);

	*rindex = '\0';

	if(strlen(pathname) == 0){
		strcpy(pathname, "/");
	}
	
	new_folder -> children = NULL;
	new_folder -> num_children = 0;
	new_folder -> parent = filetype_from_path(pathname);
	new_folder -> num_links = 2;
	new_folder -> valid = 1;
	strcpy(new_folder -> test, "test");

	if(new_folder -> parent == NULL){
		return -ENOENT;
	}

	add_child(new_folder->parent, new_folder);

	//new_folder -> type = malloc(10);
	strcpy(new_folder -> type, "directory");

	new_folder->c_time = time(NULL);
	new_folder->a_time = time(NULL);
	new_folder->m_time = time(NULL);
	new_folder->b_time = time(NULL);
	new_folder -> permissions = S_IFDIR | 0777;
	new_folder -> size = 0;
	new_folder->group_id = getgid();
	new_folder->user_id = getuid();
	new_folder -> number = index;
	new_folder -> blocks = 0;

	return 0;
}

static int myrmdir(const char * path){
	char * pathname = malloc(strlen(path) + 2);
	strcpy(pathname, path);

	char * rindex = strrchr(pathname, '/');
	char * folder_delete = malloc(strlen(rindex + 1) + 2);

	strcpy(folder_delete, rindex + 1);

	*rindex = '\0';

	if(strlen(pathname) == 0){
		strcpy(pathname, "/");
	}

	filetype * parent = filetype_from_path(pathname);

	if(parent == NULL){
		return -ENOENT;
	}

	if(parent -> num_children == 0){
		return -ENOENT;
	}

	filetype * curr_child = (parent -> children)[0];

	int index = 0;
	while(index < (parent -> num_children)){
		if(strcmp(curr_child -> name, folder_delete) == 0){
			break;
		}
		index++;
		curr_child = (parent -> children)[index];
	}

	if(index < (parent -> num_children)){
		if(((parent -> children)[index] -> num_children) != 0){
			return -ENOTEMPTY;
		}
		for(int i = index + 1; i < (parent -> num_children); i++){
			(parent -> children)[i - 1] = (parent -> children)[i];
		}
		(parent -> num_children)--;
	} else {
		return -ENOENT;
	}

	return 0;
}

int mycreate(const char * path, mode_t mode, struct fuse_file_info *fi) {
	printf("CREATEFILE\n");

	int index = find_free_inode();

	filetype * new_file = malloc(sizeof(filetype));

	char * pathname = malloc(strlen(path) + 2);
	strcpy(pathname, path);

	char * rindex = strrchr(pathname, '/');

	strcpy(new_file -> name, rindex + 1);
	strcpy(new_file -> path, pathname);

	*rindex = '\0';

	if(strlen(pathname) == 0){
		strcpy(pathname, "/");
	}	

	new_file -> children = NULL;
	new_file -> num_children = 0;
	new_file -> parent = filetype_from_path(pathname);
	new_file -> num_links = 0;
	new_file -> valid = 1;

	if(new_file -> parent == NULL){
		return -ENOENT;
	}

	add_child(new_file->parent, new_file);

	//new_file -> type = malloc(10);
	strcpy(new_file -> type, "file");

	new_file->c_time = time(NULL);
	new_file->a_time = time(NULL);
	new_file->m_time = time(NULL);
	new_file->b_time = time(NULL);

	// Doy los permisos necesarios para un archivo.
	new_file -> permissions = S_IFREG | 0777;

	new_file -> size = 0;
	new_file->group_id = getgid();
	new_file->user_id = getuid();

	new_file -> number = index;

	for(int i = 0; i < 16; i++){
		(new_file -> datablocks)[i] = find_free_db();
	}

	new_file -> blocks = 0;
	//new_file -> size = 0;

	return 0;
}

int myrm(const char * path){
	char * pathname = malloc(strlen(path) + 2);
	strcpy(pathname, path);

	char * rindex = strrchr(pathname, '/');
	char * folder_delete = malloc(strlen(rindex + 1) + 2);
	strcpy(folder_delete, rindex+1);

	*rindex = '\0';

	if(strlen(pathname) == 0){
		strcpy(pathname, "/");
	}	

	filetype * parent = filetype_from_path(pathname);

	if(parent == NULL){
		return -ENOENT;
	}
		
	if(parent -> num_children == 0){
		return -ENOENT;
	}

	filetype * curr_child = (parent -> children)[0];

	int index = 0;
	while(index < (parent -> num_children)){
		if(strcmp(curr_child -> name, folder_delete) == 0){
			break;
		}
		index++;
		curr_child = (parent -> children)[index];
	}

	if(index < (parent -> num_children)){
		if(((parent -> children)[index] -> num_children) != 0){
			return -ENOTEMPTY;
		}	
		for(int i = index+1; i < (parent -> num_children); i++){
			(parent -> children)[i - 1] = (parent -> children)[i];
		}
		(parent -> num_children)--;
	} else {
		return -ENOENT;
	}

	return 0;
}

static struct fuse_operations operations = {
	.getattr =   mygetattr,
	.readdir =   myreaddir,
	.open    =   myopen,
	.read    =   myread,
	.rename  =	 myrename,

	// DIRECOTORIOS
	.mkdir   =	 mymkdir,
	.rmdir   =   myrmdir,	

	// ARCHIVOS
	.create  = 	 mycreate,
	.unlink  = 	 myrm,
};

int main(int argc, char *argv[]){
	filetype file_array[50];

	printf("LOADING\n");

	initialize_superblock();
	initialize_root_directory();

	return fuse_main(argc, argv, &operations, NULL);
}
