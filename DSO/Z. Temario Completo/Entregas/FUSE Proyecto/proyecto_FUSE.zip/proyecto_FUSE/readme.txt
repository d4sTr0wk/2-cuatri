Proyecto de Rafael Ramírez Salas y Sofía Barril.

Lo primero es compilar el programa usando "make".
Después hay que montarlo usando "make mount".
Una vez hecho esto ya podríamos trabajar con nuestro Punto de Montaje.
Y por último para desmontarlo, nos salimos del directorio "Punto de Montaje" y hacemos "make umount".

Todos los archivos y directorios creados en el Punto de Montaje desaparecerán una vez hagamos umount,
ya que NO está implementada la funcionalidad de guardar.
