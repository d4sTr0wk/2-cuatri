#ifndef __PROYECTO_FUSE__
#define __PROYECTO_FUSE__

#define block_size 1024

#include <fuse.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdint.h>

// gcc proyectoFUSE.c -o FS `pkg-config fuse --cflags --libs`
// ./FS -f Desktop/OS/mountpoint
// ./FS -f /home/rafitata10/dso/Fuse/proyecto_fuse/punto

#define block_size 1024

typedef struct superblock {
	char datablocks[block_size*100];		//total number of data blocks
	char data_bitmap[105];	    			//array of data block numbers that are available
	char inode_bitmap[105];   				//array of inode numbers that are available
} superblock;

typedef struct inode {
	int datablocks[16];            //data block number that the inode points to
	int number;
	int blocks;                    //==number of blocks the particular inode points to
	//int link;                    //==number of links
	int size;                      //==size of file/directory
} inode;

typedef struct filetype {
	int valid;
	char test[10];
	char path[100];
	char name[100];           //name
	inode *inum;              //inode number
	struct filetype ** children;
	int num_children;
	int num_links;
	struct filetype * parent;
	char type[20];                  //==file extension
	mode_t permissions;		        // Permissions
	uid_t user_id;		            // userid
	gid_t group_id;		            // groupid
	time_t a_time;                  // Access time
	time_t m_time;                  // Modified time
	time_t c_time;                  // Status change time
	time_t b_time;                  // Creation time
	off_t size;                     // Size of the node

	int datablocks[16];
	int number;
	int blocks;

} filetype;

superblock spblock;

void initialize_superblock(){

	memset(spblock.data_bitmap, '0', 100*sizeof(char));
	memset(spblock.inode_bitmap, '0', 100*sizeof(char));
}

filetype * root;

filetype file_array[50];

void tree_to_array(filetype * queue, int * front, int * rear, int * index){

	if(rear < front)
		return;
	if(*index > 30)
		return;


	filetype curr_node = queue[*front];
	*front += 1;
	file_array[*index] = curr_node;
	*index += 1;

	if(*index < 6){

		if(curr_node.valid){
			int n = 0;
			int i;
			for(i = 0; i < curr_node.num_children; i++){
				if(*rear < *front)
					*rear = *front;
				queue[*rear] = *(curr_node.children[i]);
				*rear += 1;
			}
			while(i<5){
				filetype waste_node;
				waste_node.valid = 0;
				queue[*rear] = waste_node;
				*rear += 1;
				i++;
			}
		}
		else{
			int i = 0;
			while(i<5){
				filetype waste_node;
				waste_node.valid = 0;
				queue[*rear] = waste_node;
				*rear += 1;
				i++;
			}
		}
	}
	tree_to_array(queue, front, rear, index);
}

static int mymkdir(const char *path, mode_t mode);

int myreaddir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi );

static int mygetattr(const char *path, struct stat *statit);

int myopen(const char *path, struct fuse_file_info *fi);

int myread(const char *path, char *buf, size_t size, off_t offset,struct fuse_file_info *fi);

int mywrite(const char *path, const char *buf, size_t size, off_t offset, struct fuse_file_info *fi);

int main(int argc, char *argv[]);

#endif
